const contactos = [
    {
      id: 1,
      nombre: "Juan Morales García",
      direccion: "C/ Bilbao,4",
      telefono: "988-345356",
    },
    {
      id: 2,
      nombre: "Ana Alonso Alonso",
      direccion: "C/ Fin, 2",
      telefono: "911-345356",
    },
];

function mostrarMensage(tipo, mensajeTxt) {
  const $mensage = $d.querySelector(".mensageAccion");
  $mensage.innerHTML = `${mensajeTxt}`;
  tipo == "error"
    ? $mensage.classList.add("error")
    : $mensage.classList.add("correcto");
  setTimeout(() => $mensage.classList.remove(tipo), 1000);
}

